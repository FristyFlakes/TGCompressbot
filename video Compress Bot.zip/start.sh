python3 -m bot
