#!/bin/bash
git add .
git commit -am "make it better"
git push -u heroku master